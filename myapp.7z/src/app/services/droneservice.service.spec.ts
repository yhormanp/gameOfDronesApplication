// import { TestBed, inject } from '@angular/core/testing';

// // import { DroneserviceService } from './droneservice.service';

// describe('DroneserviceService', () => {
//   beforeEach(() => {
//     TestBed.configureTestingModule({
//       providers: [DroneserviceService]
//     });
//   });

//   // it('should ...', inject([DroneserviceService], (service: DroneserviceService) => {
//   //   expect(service).toBeTruthy();
//   // }));
// });
