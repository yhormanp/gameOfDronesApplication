
import { Injectable } from '@angular/core';
import { Http , Response, RequestOptions} from '@angular/http';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import {map} from 'rxjs/operators';
import { Player } from '../classes/player';


@Injectable()
export class DroneService {

  constructor(private http: HttpClient) { }

  private baseApiUrl='http://localhost:51181/api/';
  private playersApiUrl = this.baseApiUrl + 'players';
  private registerGameApiUrl= this.baseApiUrl + 'games'


  getPlayers(){
    return this.http.get(this.playersApiUrl).pipe(
      // map((res: Response) => res.json())
      map ((res: Response) => console.log(res))
    )};

  registerPlayers(players: Player[]){
    const _options = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    return this.http.post(this.playersApiUrl, players , _options
    )
  } ;

    registerGame(players: Player[], winner: Player){
      const request ={
        Id:0,
        player1Score: players[0].score,
        player2Score: players[1].score,
        winnerId: winner.id,
        player1Id:  players[0].id,
        player2Id:  players[1].id,
      }
      return this.http.post(this.registerGameApiUrl, request)
    };

  

}
