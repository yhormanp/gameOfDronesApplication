import { gameStatus } from '../enums/gameStatus';
import { PlayableObjects} from '../enums/objects';

export class Player{
    id: number;
    name: string;
    status: gameStatus ; // = gameStatus.Waiting;
    actionSelected: PlayableObjects ;
    score: number = 0;
    /**
     *
     */
    constructor(playersName: string, newstatus: gameStatus) {
        this.name =  playersName;
        this.status = newstatus;
    }

}