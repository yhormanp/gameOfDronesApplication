export class Game {
    player1Id: number;
    player1Score: number;
    player1Name: string;

    player2Id: number;
    player2Name: string;
    player2Score: number;

    // winnerId: number;

    /**
     *
     */
    constructor(game: Object) {
        this.player1Id =game["player1Id"];
        this.player1Score =game["player1Score"];
        this.player1Name =game["player1Name"];

        this.player2Id =game["player2Id"];
        this.player2Score =game["player2Score"];
        this.player2Name =game["player2Name"];
    }
    
}