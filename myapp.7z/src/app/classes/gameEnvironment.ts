import { gameStatus } from '../enums/gameStatus';
import { Player } from './player';
import { PlayableObjects } from '../enums/objects';
import { IRoundResponse } from '../Interfaces/IRoundResponse';
import { DroneService } from '../services/droneservice.service';

export class GameEnvironment {
    newgameStatus: gameStatus ;
    generalScore= []; //where the scores by player will be stored
    players: Player [];
    // player1: Player;
    // player2: Player;
    roundNumber: number = 0;
    winner: Player;

    /**
     *
     */
    constructor(private droneService: DroneService) {
        
    }

    /**
     *
     */

     registerPlayers(newplayers : Object)
     {
         
        this.players = [newplayers[0], newplayers[1]] ;
        this.newgameStatus = gameStatus.Playing;
        let request = [newplayers[0],newplayers[1]];
        // this.player1= newplayers[0];
        // this.player2= newplayers[1];
        this.droneService.registerPlayers(request).subscribe(data => {

            //updating players Ids
            this.players[0].id = data[0].Id;
            this.players[1].id = data[1].Id;
            console.log (data);
        });

        

        //update the roundNumber
        this.roundNumber += 1;
     }

     setSelectedElement( response: IRoundResponse):void
     {
         console.log(this.players)
        let playerToUpdate= this.players.filter(c=> c.name === response.playerName);
        playerToUpdate[0].actionSelected= response.selectedAction;

        // this.updatePlayersStatus(response.playerName);

        // playerToUpdate[0].status= gameStatus.Waiting;
        // let playerNextTurn= this.players.filter(c=> c.name !== response.playerName);
        // playerNextTurn[0] = this.
     }

     nextTurn():void
     {
         this.players[0].status= gameStatus.Waiting;
         this.players[1].status= gameStatus.Playing;
     }
     
     NextRound():void
     {
         this.roundNumber += 1;
         this.players[0].status= gameStatus.Playing;
         this.players[1].status= gameStatus.Waiting;
     }

     validateRoundAndSumScore():void{
        console.log ('test2');
        console.log (this.players);
         let result= this.checkRound();
         console.log ('result')
         console.log(result)
         if (result === true)
         {//player 1 won
            this.generalScore.push({round: this.roundNumber, winner: this.players[0]})
            this.players[0].score += 1;
            if (this.players[0].score === 3)
            {
                this.winner = this.players[0];
                this.newgameStatus =gameStatus.Finished;
                
                //save the game in the database
                this.saveGameToDatabase();
            }

         } else if (result === false){
            this.generalScore.push({round: this.roundNumber, winner: this.players[1]})
            console.log('test3')
            console.log(this.players[1])
            this.players[1].score += 1;
            console.log('test4')
            console.log(this.players[1])
            if (this.players[1].score === 3)
            {
                this.winner = this.players[1];
                this.newgameStatus =gameStatus.Finished;

                //save the game in the database
                this.saveGameToDatabase();
                
            }
         } else {
            this.generalScore.push({round: this.roundNumber, winner: null});
         }
         if (this.winner === undefined){
            console.log ('test5');
            console.log (this.players);
            this.NextRound();
         }
        
     }

     saveGameToDatabase(){
          //save the game in the database
          this.droneService.registerGame(this.players, this.winner).subscribe(data => {
            console.log (data);
        })
     }

     
     checkRound():boolean{
         
         if (this.players[0].actionSelected === this.players[1].actionSelected){
             return null; //equals
         }
         return this.players[0].actionSelected == (((this.players[1].actionSelected +1) % 3) || 3) ;

     }
     checkWinner(player: Player):void {
        if (player.score === 3)
        {
            this.winner = this.players[1];
            this.newgameStatus =gameStatus.Finished;
        }
     }

     setInitialData():void {
        this.newgameStatus = gameStatus.Registering ;
        this.generalScore= []; //where the scores by player will be stored
        this.players=   undefined;
        // player1: Player;
        // player2: Player;
        this.roundNumber = 0;
        this.winner = undefined;
     }
}