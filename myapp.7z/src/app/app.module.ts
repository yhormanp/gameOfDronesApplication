import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { HttpClientModule, HttpClient} from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { RegisterComponent } from './components/register/register.component';
import { RoundComponent } from './components/rounds/round.component';
import { ScoreComponent } from './components/generalscore/score/score.component';
import { DroneService } from './services/droneservice.service';
import { RouterModule } from '@angular/router';
import { StatisticsComponent } from './components/statistics/statistics.component';

@NgModule({
  declarations: [
    AppComponent,
    RegisterComponent,
    RoundComponent,
    ScoreComponent,
    StatisticsComponent,
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule,
    RouterModule.forRoot([
      {path: 'Home', component: AppComponent},
      {path: '', redirectTo: 'Home', pathMatch: 'full'},
      {path: '**', redirectTo: 'Home', pathMatch: 'full'},
      
    ]),

  ],
  providers: [DroneService, HttpClient],
  bootstrap: [AppComponent]
})
export class AppModule { }
