import { TestBed, async } from "@angular/core/testing";

import { AppComponent } from "./app.component";
import { RegisterComponent } from "./components/register/register.component";
import { RoundComponent } from "./components/rounds/round.component";
import { ScoreComponent } from "./components/generalscore/score/score.component";
import { BrowserModule } from "@angular/platform-browser";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { gameStatus } from "./enums/gameStatus";
import { Component } from "@angular/core";
import { PlayableObjects } from "./enums/objects";
import { DroneService } from "./services/droneservice.service";
import { HttpClientModule } from "@angular/common/http";

describe("AppComponent", () => {
  let component: AppComponent;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        AppComponent,
        RegisterComponent,
        RoundComponent,
        ScoreComponent
      ],
      imports: [BrowserModule, FormsModule, ReactiveFormsModule, HttpClientModule],
      providers: [DroneService]
    }).compileComponents();
  }));

  it("should create the app", () => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.debugElement.componentInstance;
    expect(app).toBeTruthy();
  });

  it("should register player", () => {
    var players = [
      { name: "my name as 1", status: gameStatus.Playing },
      { name: "my name as 2", status: gameStatus.Waiting }
    ];

    const fixture = TestBed.createComponent(AppComponent);
    component = fixture.componentInstance;

    component.onRegisterPlayers(players);
    expect(component.gameEnvironment.players [0]).toEqual(players[0]);
    expect(component.gameEnvironment.players [1]).toEqual(players[1]);
  });

  it("should register selected action per player", () => {
    const fixture = TestBed.createComponent(AppComponent);
    component = fixture.componentInstance;

    //registering players:
    var players = [
      { name: "my name as 1", status: gameStatus.Playing },
      { name: "my name as 2", status: gameStatus.Waiting }
    ];

    var mockedPlayerToCompare = {
      name: "my name as 1",
      status: gameStatus.Waiting,
      actionSelected: 1
    };
    component.onRegisterPlayers(players);

    var response = {
      playerName: "my name as 1",
      selectedAction: PlayableObjects.Rock
    };

    component.onSelectedAction(response);
    expect(component.gameEnvironment.players[0]).toEqual(mockedPlayerToCompare);
  });

  it("Player 2 Win", () => {
    const fixture = TestBed.createComponent(AppComponent);
    component = fixture.componentInstance;

    //registering players:
    var players = [
      { name: "my name as 1", status: gameStatus.Playing },
      { name: "my name as 2", status: gameStatus.Waiting }
    ];

    // var mockedPlayerToCompare= {name :'my name as 1', status: gameStatus.Waiting, actionSelected: 1};
    component.onRegisterPlayers(players);

    var response1 = {
      playerName: "my name as 1",
      selectedAction: PlayableObjects.Rock
    };
    var response2 = {
      playerName: "my name as 2",
      selectedAction: PlayableObjects.Paper
    };

    component.onSelectedAction(response1);
    component.onSelectedActionAndValidate(response2);

    expect(component.gameEnvironment.players[1].score).toBeDefined();
  });

  it("Player 1 Win", () => {
    const fixture = TestBed.createComponent(AppComponent);
    component = fixture.componentInstance;

    //registering players:
    var players = [
      { name: "my name as 1", status: gameStatus.Playing },
      { name: "my name as 2", status: gameStatus.Waiting }
    ];

    // var mockedPlayerToCompare= {name :'my name as 1', status: gameStatus.Waiting, actionSelected: 1};
    component.onRegisterPlayers(players);

    var response1 = {
      playerName: "my name as 1",
      selectedAction: PlayableObjects.Paper
    };
    var response2 = {
      playerName: "my name as 2",
      selectedAction: PlayableObjects.Rock
    };

    component.onSelectedAction(response1);
    component.onSelectedActionAndValidate(response2);

    expect(component.gameEnvironment.players[0].score).toBeDefined();
  });

  it("draw", () => {
    const fixture = TestBed.createComponent(AppComponent);
    component = fixture.componentInstance;

    //registering players:
    var players = [
      { name: "my name as 1", status: gameStatus.Playing },
      { name: "my name as 2", status: gameStatus.Waiting }
    ];

    // var mockedPlayerToCompare= {name :'my name as 1', status: gameStatus.Waiting, actionSelected: 1};
    component.onRegisterPlayers(players);

    var response1 = {
      playerName: "my name as 1",
      selectedAction: PlayableObjects.Paper
    };
    var response2 = {
      playerName: "my name as 2",
      selectedAction: PlayableObjects.Paper
    };

    component.onSelectedAction(response1);
    component.onSelectedActionAndValidate(response2);

    expect(component.gameEnvironment.players[0].score).toBeUndefined();
    expect(component.gameEnvironment.players[1].score).toBeUndefined();
  });

  it("set initial values", () => {
    const fixture = TestBed.createComponent(AppComponent);
    component = fixture.componentInstance;

    //registering players:
    var players = [
      { name: "my name as 1", status: gameStatus.Playing },
      { name: "my name as 2", status: gameStatus.Waiting }
    ];

    component.onRegisterPlayers(players);

    var response1 = {
      playerName: "my name as 1",
      selectedAction: PlayableObjects.Rock
    };
    var response2 = {
      playerName: "my name as 2",
      selectedAction: PlayableObjects.Paper
    };

    component.onSelectedAction(response1);
    component.onSelectedActionAndValidate(response2);

    expect(component.gameEnvironment.players[1].score).toBeDefined();

    component.setinitialValues();

    expect(component.gameEnvironment.players).toBeUndefined();
    expect(component.gameEnvironment.generalScore).toEqual([]);
    expect(component.gameEnvironment.newgameStatus).toEqual(
      gameStatus.Registering
    );
    expect(component.gameEnvironment.winner).toBeUndefined;
  });
});
