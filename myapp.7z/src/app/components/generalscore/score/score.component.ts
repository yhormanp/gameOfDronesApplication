import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-score',
  templateUrl: './score.component.html',
  styleUrls: ['./score.component.css']
})
export class ScoreComponent implements OnInit {

  @Input()
  generalScore: any;
  // fakeData =[
  //   {round:1, winner: 'playerA'},
  //   {round:2, winner: 'playerA'},
  //   {round:3, winner: 'playerB'},
  // ]
  constructor() { 
    // console.log(this.generalScore)
  }

  ngOnInit() {
    // console.log(this.generalScore)
  }

}
