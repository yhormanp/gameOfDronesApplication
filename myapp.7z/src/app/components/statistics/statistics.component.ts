import { Component, OnInit } from "@angular/core";
import { DroneService } from "src/app/services/droneservice.service";
import { Game } from "src/app/classes/game";

@Component({
  selector: "app-statistics",
  templateUrl: "./statistics.component.html",
  styleUrls: ["./statistics.component.css"]
})
export class StatisticsComponent implements OnInit {
  games: Game[] = [];
  playerName: string;
  hideStatistics: boolean = false;
  constructor(private droneService: DroneService) {}

  ngOnInit() {
    this.search100Games();
  }

  search100Games():void{
    this.droneService.getGames().subscribe( (data: Object[]) => {
      console.log( data);
        this.games = [];
      data.map( record => {
        this.games.push(new Game(record))
      });
    });
  }

  searchByPlayerName():void {
    if (this.playerName === "" || this.playerName === undefined)
    { 
      this.search100Games();
    } else {
      this.droneService.getGamesByPlayerName(this.playerName).subscribe( (data: Object []) => {
        console.log (data);
        this.games = [];
        data.map( record => {
          
          this.games.push(new Game(record))
        });
      })
    }
  }

  toogleView()
  {
    this.hideStatistics = !this.hideStatistics;
  }
}
