import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RoundComponent } from './round.component';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule, FormsModule } from '@angular/forms';

describe('RoundComponent', () => {
  let component: RoundComponent;
  let fixture: ComponentFixture<RoundComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        ReactiveFormsModule,
        FormsModule,
      ],
      declarations: [ RoundComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    TestBed.configureTestingModule({
      
      declarations: [
       FormGroup, RoundComponent
      ],
      imports: [
        ReactiveFormsModule,
        FormsModule,
      ],
    })
    fixture = TestBed.createComponent(RoundComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('rounds form should be invalid', ()=> {
    component.roundsForm.controls['actionItem'].setValue('');
    expect(component.roundsForm.valid).toBeFalsy();
  });

  it('rounds form should be valid', ()=> {
    component.roundsForm.controls['actionItem'].setValue('1');
    expect(component.roundsForm.valid).toBeTruthy();
  });
  it('button ok clicked and emit launched', () => {
    component.playerName = "nameA";
    component.roundsForm.controls['actionItem'].setValue('1');
    
    component.selectedAction.subscribe(g=> {
      expect( g).toEqual({playerName: 'nameA', selectedAction: '1'});

    })
    component.selected();
    // expect(component.selected).toHaveBeenCalled();
  })
 
});
