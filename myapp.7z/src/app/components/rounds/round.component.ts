import { Component, OnInit, Input, Output, EventEmitter } from "@angular/core";
import { PlayableObjects } from "../../enums/objects";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { IRoundResponse } from "../../Interfaces/IRoundResponse";


@Component({
  selector: "app-round",
  templateUrl: "./round.component.html",
  styleUrls: ["./round.component.css"]
})
export class RoundComponent implements OnInit {
  @Input()
  roundNumber: number;
  @Input()
  playerName: string;
  @Output()
  selectedAction: EventEmitter<IRoundResponse> = new EventEmitter<
    IRoundResponse
  >();

  objectsToSelect = PlayableObjects;
  keys = Object.keys;
  roundsForm: FormGroup;

  constructor(private fb: FormBuilder) {
    // console.log(this.objectsToSelect);
  }

  ngOnInit() {
    this.roundsForm = this.fb.group({
      actionItem: ["", Validators.required]
    });
  }

  selected(): void {
    // console.log("action is : " + this.roundsForm.controls["actionItem"].value);
    let response = {
      playerName: this.playerName,
      selectedAction: this.roundsForm.controls["actionItem"].value
    };
    this.selectedAction.emit(response);
  }
}
