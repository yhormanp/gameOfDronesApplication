import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RegisterComponent } from './register.component';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule, FormGroup, FormBuilder, Validators} from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Player } from '../../classes/player';
import { gameStatus } from '../../enums/gameStatus';

describe('RegisterComponent', () => {
  let component: RegisterComponent;
  let fixture: ComponentFixture<RegisterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        ReactiveFormsModule,
        FormsModule,
      ],
      declarations: [ RegisterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        ReactiveFormsModule,
        FormsModule,
      ],
      declarations: [
        FormGroup, RegisterComponent
      ]
     
    })
    fixture = TestBed.createComponent(RegisterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

   it('rounds form should be invalid', ()=> {
    component.registerForm.controls['player1'].setValue('');
    component.registerForm.controls['player2'].setValue('');
    expect(component.registerForm.valid).toBeFalsy();
  });

  it('rounds form should be valid', ()=> {
    component.registerForm.controls['player1'].setValue('my New Name as Player 1');
    component.registerForm.controls['player2'].setValue('my New Name as Player 2');
    expect(component.registerForm.valid).toBeTruthy();
  });

  it('button ok clicked and emit launched', () => {
    component.registerForm.controls['player1'].setValue('my New Name as Player 1');
    component.registerForm.controls['player2'].setValue('my New Name as Player 2');


    var player1= new  Player('my New Name as Player 1', gameStatus.Playing);
    player1.score = 0;
    var player2= new  Player('my New Name as Player 2', gameStatus.Waiting);
    player1.score = 0;

    component.registerPlayers.subscribe(g=> {
      expect( g[0]).toEqual(player1);
      expect(g [1]).toEqual(player2);
    })
    component.save();
    // expect(component.selected).toHaveBeenCalled();
  })
});
