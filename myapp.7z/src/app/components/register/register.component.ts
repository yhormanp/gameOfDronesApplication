import { Player } from "../../classes/player";
import { Component, OnInit, Output, EventEmitter } from "@angular/core";
import { FormGroup, FormBuilder } from "@angular/forms";
import { Validators } from "@angular/forms";
import { gameStatus } from "../../enums/gameStatus";

@Component({
  selector: "app-register",
  templateUrl: "./register.component.html",
  styleUrls: ["./register.component.css"]
})
export class RegisterComponent implements OnInit {
  registerForm: FormGroup;
  @Output() registerPlayers: EventEmitter<Object> = new EventEmitter<Object>();

  constructor(private fb: FormBuilder) {
   
  }

  ngOnInit() {
    this.registerForm = this.fb.group({
      player1: ["", Validators.required],
      player2: ["", Validators.required]
    });
  }

  save(): void {
    // console.log("saved");
    //create a new player instance
    const controls = this.registerForm.controls;
    let players = [
       new Player(controls["player1"].value, gameStatus.Playing) ,
       new Player(controls["player2"].value, gameStatus.Waiting) 
    ];

    this.registerPlayers.emit(players);
  }
}
