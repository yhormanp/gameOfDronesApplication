import { Component } from '@angular/core';
import { GameEnvironment } from './classes/gameEnvironment';
import { gameStatus } from './enums/gameStatus';
import { IRoundResponse } from './Interfaces/IRoundResponse';
import { DroneService } from './services/droneservice.service';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  gameEnvironment = new GameEnvironment(this.ds);
  

  title = 'app works!';
  
  /**
   *
   */
  constructor(private ds: DroneService) {
    this.gameEnvironment.newgameStatus= gameStatus.Registering;   
      
  }

  onRegisterPlayers( players: Object):void
  {
    this.gameEnvironment.registerPlayers(players);
    // console.log ( this.gameEnvironment);
  }

  onSelectedAction(response: IRoundResponse): void {
    // console.log (response);
    this.gameEnvironment.setSelectedElement(response);
    this.gameEnvironment.nextTurn();
  }

  onSelectedActionAndValidate(response: IRoundResponse): void {
    console.log ('test');
    console.log (response);
    this.gameEnvironment.setSelectedElement(response);
    this.gameEnvironment.validateRoundAndSumScore();
  }

  setinitialValues(){
    this.gameEnvironment.setInitialData();
  }

}
