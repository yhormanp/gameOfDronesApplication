import { PlayableObjects} from '../enums/objects';
export interface IRoundResponse {
    playerName: string;
    selectedAction: PlayableObjects;
}