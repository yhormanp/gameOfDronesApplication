export enum PlayableObjects {
    Rock =1,
    Paper =2,
    Scissors=3
}