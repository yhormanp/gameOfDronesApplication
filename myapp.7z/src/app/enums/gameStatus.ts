export enum gameStatus {
    Waiting = 0,
    Playing = 1,
    Finished = 2,
    Registering = 3,
}